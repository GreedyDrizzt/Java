import java.util.ArrayList;
import java.util.Date;

public class SubmissionInfo implements Submission{
	Date Time;
	int Grade;
	Submission Submit;
	
	public SubmissionInfo()
	{
		Time = null;
		Grade = 0;
		Submit = null;
	}
	
	public Date getTime()
	{
		return Time;
	}
	
	public Integer getGrade()
	{
		return Grade;
	}
	public void SetGrade(int g)
	{
		Grade = g;
	}
	public Submission getSubmit()
	{
		return Submit;
	}

	@Override
	public String getUnikey() {
		// TODO Auto-generated method stub
		return null;
	}
	
}
