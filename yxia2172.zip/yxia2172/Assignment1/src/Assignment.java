import java.util.ArrayList;
import java.util.Date;
import java.util.Hashtable;
import java.util.List;
public class Assignment implements SubmissionHistory 
{
	/* *
	* Default constructor
	*/
	Hashtable<String, ArrayList<SubmissionInfo>> assignment = new Hashtable<String, ArrayList<SubmissionInfo>>();
	
	public Assignment () {		
		assignment = null;
	}
	
	@Override
	public Integer getBestGrade (String unikey) {
		ArrayList<SubmissionInfo> sub = assignment.get(unikey);
		if (sub == null) return null;
		SubmissionInfo temp = sub.get(0);
		for(SubmissionInfo g : sub)
		{
			if (temp.getGrade()<g.getGrade() ) temp=g;
		}
		return temp.getGrade();
	}
	//public int getGrade(){return Grade;}
	@Override
	public Submission getSubmissionFinal ( String unikey ) {
		ArrayList<SubmissionInfo> sub = assignment.get(unikey);
		if (sub == null) return null;
		SubmissionInfo temp = sub.get(0);
		for (SubmissionInfo g : sub)
		{
			if(temp.getTime().compareTo(g.getTime())<0) temp = g;
		}
		return temp.getSubmit();
	}
	@Override
	public Submission getSubmissionBefore ( String unikey , Date deadline ) {
		ArrayList<SubmissionInfo> sub = assignment.get(unikey);
		if (sub == null) return null;
		SubmissionInfo temp = sub.get(0);
		for (SubmissionInfo g : sub)
		{
			if((temp.getTime().compareTo(g.getTime())>0) && (temp.getTime().compareTo(deadline)<0)) temp = g;
		}
		return temp.getSubmit();
	}
	@Override
	public Submission add ( String unikey , Date timestamp , Integer grade ) {
		
	return null ;
	}
	@Override
	public void remove ( Submission submission ) {
	// TODO Implement this , ideally in better than O ( n )
	}
	@Override
	public List<String> listTopStudents () {
	// TODO Implement this , ideally in better than O ( n )
	// ( you may ignore the length of the list in the analysis )
	return null ;
	}
	@Override
	public List<String> listRegressions () {
	// TODO Implement this , ideally in better than O ( n ^2)
	return null ;
	}
}
