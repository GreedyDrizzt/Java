import java.util.ArrayList;

public class SubmitList {
	ArrayList<SubmissionInfo> submits;

	public ArrayList<SubmissionInfo> getInfo()
	{
		return submits;
	}
}
