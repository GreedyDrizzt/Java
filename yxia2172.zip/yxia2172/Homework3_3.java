import java.util.Scanner;
public class Homework3_3 {
	public static void main(String[] args)
	{
		Scanner s = new Scanner(System.in);
		int odd;
		
		do //The do-while loop provides the control of the number, to ensure the figure is an odd!
		{
			
			System.out.println("Please enter a odd number:");
			odd = s.nextInt();
		}while(odd % 2==0);//By the example, it's suitable to use Scanner to enter the odd figure.
		int line=(odd+1)/2;
		for (int i = 1;i<=line;i++)
		{
			for (int k = 1;k<=line-1;k++)
			{
				System.out.print(" ");
			}
			for (int j = 1;j<=2*i-1;j++)
			{
				System.out.print("*");
			}
			System.out.println("");
		}//Finally the for loop would provide the main structure of pyramid!
	}
}
