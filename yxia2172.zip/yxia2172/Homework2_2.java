/*The program asked user to enter two integer to represent the day today and the time user
 * would like. The final result would be output by a switch method.*/
public class Homework2_2 {
	public static void main(String[] args)
	{
		
		int today = Integer.parseInt(args[0]);
		int due = Integer.parseInt(args[1]);//The two declaration defines the figure should be input
		int days = due % 7;
		int aimday;
		aimday = today + days -1;
		switch(aimday)//Here is a condition structure by using switch to choose which day is it today.
		{
			case 1:
			System.out.println("Today is Monday!");
			break;
			
			case 2:
			System.out.println("Today is Tuesday!");
			break;

			case 3:
			System.out.println("Today is Wednesday!");
			break;

			case 4:
			System.out.println("Today is Thursday!");
			break;

			case 5:
			System.out.println("Today is Friday!");
			break;

			case 6:
			System.out.println("Today is Saturday!");
			break;

			default:
			System.out.println("Today is Sunday!");
			break;
		}
	}
}
