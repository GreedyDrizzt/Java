import java.util.Iterator;

/*
 * This class is the one you need to complete. Only the member variables
 * and constructor have been implemented for you.
 */

public class LinkedPositionalList<E> implements PositionalList<E>,Iterable {
	
	/*
	 * This nested class contains a completed implementation of Position
	 * which you should use within LinkedPositionalList.
	 * 
	 * You do not need to edit this class.
	 */
	private class Node<E> implements Position<E> {
		
		private Node<E> prev;
		private Node<E> next;
		private E element;
		
		public Node(E element) {
			this.element = element;
			this.prev = null;
			this.next = null;
		}
		
		public Node<E> getPrev() {return prev;}
		public Node<E> getNext() {return next;}
		public E getElement() {return element;}
		public void setPrev(Node<E> prev) {this.prev = prev;}
		public void setNext(Node<E> next) {this.next= next;}
		public void setElement(E element) {this.element = element;}
	}
	
	//The header sentinel
	private Node<E> header;

	//The trailer sentinel
	private Node<E> trailer;

	//The number of positions in the list, not counting sentinels
	int size;

	//This constructor creates an empty list
	public LinkedPositionalList() {
		header = new Node<E>(null);
		trailer = new Node<E>(null);
		header.setNext(trailer);
		trailer.setPrev(header);
		size = 0;
	}

	//TODO: You will need to implement the remaining methods!

	@Override
	public int size() {
		return size;
	}

	@Override
	public boolean isEmpty() {
		if (size == 0) return true;
		else return false;
	}

	@Override
	public Position<E> first() {
		// TODO Implement this.
		return header.getNext() != trailer ? header.getNext() : null;
	}

	@Override
	public Position<E> last() {
		// TODO Implement this.
		return trailer.getPrev() != header ? trailer.getPrev() : null;
	}

	@Override
	public Position<E> before(Position<E> p) {
		if (((Node<E>)p).getPrev() == header) return null;
		else return ((Node<E>)p).getPrev();
	}

	@Override
	public Position<E> after(Position<E> p) {
		if (((Node<E>)p).getNext() == trailer) return null;
		else return ((Node<E>)p).getNext();
	}

	@Override
	public Position<E> addFirst(E e) {
		
		Node<E> toAdd = new Node<E> (e);
		//if(size != 0)
		 // {
			toAdd.setNext(header.getNext());
			header.getNext().setPrev(toAdd);
		    header.setNext(toAdd);
		    toAdd.setPrev(header);
		    size++;
		  /*} else {
		    header = toAdd;
		    trailer = toAdd;
		    toAdd.next = null;
		    size++;
		  }*/
		return toAdd;
	}

	@Override
	public Position<E> addLast(E e) {
		Node<E> toAdd = new Node<E> (e);
		toAdd.setPrev(trailer.getPrev());
		trailer.getPrev().setNext(toAdd);
	    trailer.setPrev(toAdd);
	    toAdd.setNext(trailer);
	    size++;
		return toAdd;
	}

	@Override
	public Position<E> addBefore(Position<E> p, E e) {
		Node<E> toAdd = new Node<E> (e);
		toAdd.next = (Node<E>)p;
		toAdd.prev = ((Node<E>)p).getPrev();
		((Node<E>)p).getPrev().setNext(toAdd);
		((Node<E>)p).setPrev(toAdd);
		size++;
		return toAdd;
	}

	@Override
	public Position<E> addAfter(Position<E> p, E e) {
		Node<E> toAdd = new Node<E> (e);
		toAdd.prev = (Node<E>)p;
		toAdd.next = ((Node<E>)p).getNext();
		((Node<E>)p).getNext().setPrev(toAdd);
		((Node<E>)p).setNext(toAdd);
		return toAdd;
	}

	@Override
	public E set(Position<E> p, E e) {
		E prevE = ((Node<E>)p).getElement();
		((Node<E>)p).setElement(e);
		return prevE;
	}

	@Override
	public E remove(Position<E> p) {
		E prevE = ((Node<E>)p).getElement();
		((Node<E>)p).getPrev().setNext(((Node<E>)p).getNext());
		((Node<E>)p).getNext().setPrev(((Node<E>)p).getPrev());
		size--;
		return prevE;
	}
	public Iterator<E> iterator() {
        return new PositionalListIterator<E>(this, header);
    }

	@Override
	public boolean hasNext() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Object next() {
		// TODO Auto-generated method stub
		return null;
	}
	
	
}