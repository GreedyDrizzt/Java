import java.util.Iterator;
import java.util.NoSuchElementException;
public class PositionalListIterator<E> implements Iterator<E>{
	private PositionalList<E> list;
	private Position<E> position;

	public PositionalListIterator(PositionalList<E> pl, Position<E> p) { 
		list = pl;
		position = p;
	}
	
	@Override
	public boolean hasNext() {
		return list.after(position)!=null;
	}

	@Override
	public E next() {
		E after;
		if (!hasNext())
		{
			throw new NoSuchElementException();
		}
		else {
			after = list.after(position).getElement();
			position = list.after(position);
		}
		return after;
	}
}
