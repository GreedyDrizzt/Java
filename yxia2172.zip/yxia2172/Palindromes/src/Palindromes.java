import java.util.*;
import java.util.LinkedList;
public class Palindromes {
	
    public static boolean isPalindromeSentence(String sentence) {
        Stack <Character> p = new Stack<Character>();
        Queue <Character> q = new LinkedList<Character>();
        sentence.toLowerCase().replace(" ", "");
        boolean c;
        for (int i = 0; i < sentence.length(); i++) {
            c = Character.isAlphabetic(sentence.charAt(i));
            char a;
            if (c == true)  {
                a = Character.toLowerCase(sentence.charAt(i));
                p.push(a);
                q.add(a);
            }
            else if (c == false)    
			{
                continue;
            }
            
        }
        String reversed = "";
        String words = "";
        while (!p.isEmpty())    {
            reversed += p.pop();
        }
        while (!q.isEmpty())    {
            words += q.poll();
        }
        return words.equals(reversed);
    }
}
