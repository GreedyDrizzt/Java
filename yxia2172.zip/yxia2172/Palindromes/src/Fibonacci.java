import java.util.Stack;
public class Fibonacci {

	/**
	* Given a number n, return a stack containing the Fibonacci numbers
	* from f(0) up to and including f(n)
	*/
	public static Stack<Integer> getNumbers(int n) {
		Stack<Integer> fibo = new Stack<>();
		int count = 0, num1, num2;
		while(count<=n)
		{
			if (count == 0)
			{
				num2=0;
			}else if(count == 1)
			{
				num2=0;
			}else{
				int temp = fibo.pop();
				
				num1 = fibo.peek();
				num2 = temp + num1;
				fibo.push(temp);

			}

			fibo.push(num2);
			count++;
		}
		return fibo;
	}


}