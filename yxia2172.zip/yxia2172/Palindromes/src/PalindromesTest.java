import static org.junit.Assert.*;

import org.junit.Test;

public class PalindromesTest {

	@Test
	public void test() {
		assertEquals(true, Palindromes.isPalindromeSentence("Eye"));
		assertEquals(true, Palindromes.isPalindromeSentence("; ;"));
		assertEquals(false, Palindromes.isPalindromeSentence("cye"));
		assertEquals(true, Palindromes.isPalindromeSentence(";a ;"));
		assertEquals(true, Palindromes.isPalindromeSentence("Madam, I'm Adam"));
		
	}

}
