import java.util.Scanner;
public class Homework3_4 {
	public static void main(String[] args)
	{
		
		java.util.Random random=new java.util.Random();
		int a = random.nextInt(2);//Randomly create a figure from 0 to 2.
		String comp = null ;
		if (a==0) comp="rock";
		else if (a==1) comp="scissor";
		else if (a==2) comp="paper";//For each condition, the figure will apply a typical result.
		Scanner s = new Scanner(System.in);
		System.out.println("Please enter scissor,rock or paper: ");
		String reply=s.nextLine();//Let the user to enter a result.
		if (reply.equalsIgnoreCase(comp)){
			System.out.println("The match draws! The computer thought the same as you");
		}//If the result are same, the match draws
		else
		{
			if (reply.equalsIgnoreCase("scissor") && (a==0))
			{
				System.out.println("You lose! The computer guessed "+comp);
			}
			else if ((reply.equalsIgnoreCase("Scissor")) && (a==2))
			{
				System.out.println("You win!The computer guessed "+comp);
			}
			else if ((reply.equalsIgnoreCase("rock")) && (a==1))
			{
				System.out.println("You win!The computer guessed "+comp);
			}
			else if ((reply.equalsIgnoreCase("rock")) && (a==2))
			{
				System.out.println("You lose!The computer guessed "+comp);
			}
			else if ((reply.equalsIgnoreCase("paper")) && (a==0))
			{
				System.out.println("You win!The computer guessed "+comp);
			}
			else if ((reply.equalsIgnoreCase("paper")) && (a==1))
			{
				System.out.println("You lose!The computer guessed "+comp);
			}
		}//In such an else condition, by analysis, the situation could be divide into 6 conditions where the match does not draw.
	}
}
