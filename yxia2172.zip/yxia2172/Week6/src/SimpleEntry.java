
public interface SimpleEntry {
	public Integer getKey();
	public String getValue();
}
