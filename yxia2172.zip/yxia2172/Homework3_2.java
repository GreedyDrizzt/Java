/*The program aims to output a triangle consists of numbers from 1 to 9.*/
import java.util.Scanner;

public class Homework3_2 {
	public static void main(String[] args)
	{
		Scanner s = new Scanner(System.in);
		System.out.println("Please enter a number from 1 to 9:");
		int num = s.nextInt();//Using Scanner to make the process of input more clear!
		if ((num>9) || (num<0) ){
			System.out.println("Please enter a number from 1 to 9!");
			System.out.println("The program has been exited! Please restart it to enter the right number!");
			System.exit(0);
		}//When the figure input does not fulfill the requirement, The program will end!
		
		for(int i=1;i<=num;i++)
		{
			for(int j=1;j<=i;j++)
			{
				System.out.print(j);
			}
			System.out.println("");
		}//If the figure fulfill the requirement, The program will run correctly!
	}
}
