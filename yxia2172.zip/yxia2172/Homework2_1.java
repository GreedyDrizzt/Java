import java.util.Scanner;

public class Homework2_1 
/*This program aims to output the area and perimeter by entering two integers
 * The diagonal would also be calculated by Math.sqrt method*/
{
	public static void main(String[] args)
	{
		int length, width;
		length = Integer.parseInt(args[0]);
		width = Integer.parseInt(args[1]);
		int area, perimeter;
		double diagonal;
		area = length * width;
		perimeter = 2*(length+width);
		diagonal = Math.sqrt(length*length + width*width);
		System.out.println("The area is "+area+", and the perimeter is "+perimeter+", and the diagonal is "+diagonal+".");
		
	}
}
