
public interface BinaryTree<T> {
	
}
