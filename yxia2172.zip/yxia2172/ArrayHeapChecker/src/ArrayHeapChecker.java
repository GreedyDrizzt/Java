public class ArrayHeapChecker {

	//Check if the given array is a representation of a binary tree
	public static boolean isBinaryTree(Integer[] array) {

			for (int i = array.length-1;i>0;i--)
			{
				if (array[i]!=null &&array[(i-1)/2]==null) return false;
			}
		
		return true;
	}
	
	//Check if the given array is a complete binary tree
	public static boolean isCompleteBinaryTree(Integer[] array) {
		if(!isBinaryTree(array)) {
			return false;
		}
		else
		{
			for (int i = array.length-2;i>0;i--)
			{
				if(array[i]==null && array[i+1]!=null) return false;
			}
		}
		return true;
	}
	
	//Check if the given array is a min-heap
	public static boolean isMinHeap(Integer[] array) {
		if(!isCompleteBinaryTree(array)) {
			return false;
		}
		if (array.length == 0 || array[0]==null) return true;
		for(int i = array.length-1;i>0;i--)
		{
			if (array[i]==null) continue;
			else if (array[i]<array[(i-1)/2]) return false;
			//if(array[i]<array[0]) return false;
			
		}
		return true;
	}
}