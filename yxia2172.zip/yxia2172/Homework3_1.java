import java.util.Scanner;
/*The program aim to enter the grade and output the mark range.*/
public class Homework3_1 {
	public static void main(String[] args)
	{
		Scanner s = new Scanner(System.in);
		System.out.print("Please enter a mark:");
		String line=s.nextLine();//Using the Scanner tool, we could enter the typical result without being afraid of misunderstand.
		char C=line.charAt(0);
		if (C=='H')
		{
			System.out.println("Your grade range is 85%--100%");
		}
		else if (C=='D')
		{
			System.out.println("Your grade range is 75%--84%");
		}
		else if (C=='C')
		{
			System.out.println("Your grade range is 65%--74%");
		}
		else if (C=='P')
		{
			System.out.println("Your grade range is 50%--64%");
		}
		else if (C=='F')
		{
			System.out.println("Your grade range is 0%-49");
		}
		else
		{
			System.out.println("Please enter a right grade!");
		}//Here is a long if, else if and else structure to judge the mark range by the grade input.
	}
}
