import java.util.List;
public class StatisticsCalculator {
	int mark;
	public StatisticsCalculator() {
		
	}

    public void addScore(int score) {
    	mark = score;
	}

    public double getAverage() {
    	int sum = 0;
		for (int i = 0;i<mark.size();i++)
		{
			sum+=mark.get(i);
		}
		int num = mark.size();
		double average = sum/num;
		return average;
	}

    public String getGrade() {
		if (mark>=85) return "HD";
		else if ( mark>=75 ) return "D";
		else if (mark>=65) return "CR";
		else if (mark >= 50) return "P";
		else return "F";
	}
    
}
