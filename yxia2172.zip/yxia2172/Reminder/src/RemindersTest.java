import static org.junit.Assert.*;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import org.junit.Test;

public class RemindersTest {

	@Test
	public void test() throws ParseException {
		Reminders remind = new Reminders();
		SimpleDateFormat d = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		remind.setReminder(d.parse("2010-01-02 08:00:00"), "no reminders");
		remind.setReminder(d.parse("2010-01-02 10:00:00"), "the first reminder");
		remind.setReminder(d.parse("2010-01-02 15:00:00"), "the next 2 reminders");
		remind.setReminder(d.parse("2010-01-03 09:59:59"), "the next reminder");
		remind.setReminder(d.parse("2010-01-03 12:00:00"), "the last reminder");
		remind.setReminder(d.parse("2010-01-03 13:00:00"), "no reminders");
		remind.setReminder(d.parse("2014-01-03 13:00:00"), "no reminders");
		
		ArrayList<String> array = new ArrayList<>();
	}

}
